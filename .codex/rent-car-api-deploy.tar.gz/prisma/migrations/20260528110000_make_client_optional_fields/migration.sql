ALTER TABLE "Client"
  ALTER COLUMN "email" DROP NOT NULL,
  ALTER COLUMN "driverLicenseNumber" DROP NOT NULL,
  ALTER COLUMN "emergencyContactName" DROP NOT NULL,
  ALTER COLUMN "emergencyContactPhone" DROP NOT NULL;
