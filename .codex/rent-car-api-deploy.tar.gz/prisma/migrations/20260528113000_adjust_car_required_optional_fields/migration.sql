UPDATE "Car"
SET "highSeasonPrice" = "dailyPrice"
WHERE "highSeasonPrice" IS NULL;

UPDATE "Car"
SET "deposit" = 0
WHERE "deposit" IS NULL;

ALTER TABLE "Car"
  ALTER COLUMN "plate" DROP NOT NULL,
  ALTER COLUMN "color" DROP NOT NULL,
  ALTER COLUMN "highSeasonPrice" SET NOT NULL,
  ALTER COLUMN "deposit" SET NOT NULL;
