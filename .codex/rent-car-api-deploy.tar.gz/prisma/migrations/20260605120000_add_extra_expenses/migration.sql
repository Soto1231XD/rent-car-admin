CREATE TYPE "ExtraExpenseStatus" AS ENUM ('PENDIENTE', 'PAGADO', 'CANCELADO');

CREATE TABLE "ExtraExpense" (
    "id" TEXT NOT NULL,
    "carId" TEXT NOT NULL,
    "concept" TEXT NOT NULL,
    "cost" DECIMAL(65,30) NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "status" "ExtraExpenseStatus" NOT NULL DEFAULT 'PENDIENTE',
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ExtraExpense_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "ExtraExpense_carId_idx" ON "ExtraExpense"("carId");

ALTER TABLE "ExtraExpense"
ADD CONSTRAINT "ExtraExpense_carId_fkey"
FOREIGN KEY ("carId") REFERENCES "Car"("id")
ON DELETE RESTRICT ON UPDATE CASCADE;
