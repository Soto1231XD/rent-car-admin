ALTER TABLE "Car"
ADD COLUMN "engineType" TEXT,
ADD COLUMN "displacement" TEXT,
ADD COLUMN "hasCarPlay" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN "trunkCapacity" TEXT;
