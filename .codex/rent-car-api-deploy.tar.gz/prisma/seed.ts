import { scryptSync } from 'node:crypto';
import { PrismaClient, UserRole } from '@prisma/client';
import { PrismaPg } from '@prisma/adapter-pg';

const adapter = new PrismaPg({
  connectionString: process.env.DATABASE_URL,
});

const prisma = new PrismaClient({ adapter });

const adminUser = {
  fullName: 'Administrador Rentamivar',
  email: 'admin@rentamivar.com',
  password: 'Admin123!',
  role: UserRole.ADMIN,
};

async function main() {
  await prisma.user.upsert({
    where: { email: adminUser.email },
    update: {
      fullName: adminUser.fullName,
      passwordHash: hashPassword(adminUser.password),
      role: adminUser.role,
      isActive: true,
    },
    create: {
      fullName: adminUser.fullName,
      email: adminUser.email,
      passwordHash: hashPassword(adminUser.password),
      role: adminUser.role,
      isActive: true,
    },
  });

  console.log('Seed completed: admin user upserted.');
  console.log(`Admin user: ${adminUser.email}`);
}

function hashPassword(password: string) {
  const salt = 'rentamivar-admin-seed';
  const hash = scryptSync(password, salt, 64).toString('hex');

  return `scrypt:${salt}:${hash}`;
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
