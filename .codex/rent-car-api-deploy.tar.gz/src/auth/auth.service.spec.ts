import { UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Test, TestingModule } from '@nestjs/testing';
import { scryptSync } from 'node:crypto';
import { PrismaService } from '../prisma/prisma.service';
import { AuthService } from './auth.service';

describe('AuthService', () => {
  let service: AuthService;

  const prismaMock = {
    user: {
      findUnique: jest.fn(),
    },
  };

  const jwtMock = {
    signAsync: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        {
          provide: PrismaService,
          useValue: prismaMock,
        },
        {
          provide: JwtService,
          useValue: jwtMock,
        },
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
    jest.clearAllMocks();
  });

  it('should return an access token for valid credentials', async () => {
    prismaMock.user.findUnique.mockResolvedValue({
      id: 'user-1',
      email: 'admin@rentamivar.com',
      fullName: 'Admin',
      role: 'ADMIN',
      isActive: true,
      passwordHash: hashPassword('Admin123!'),
    });
    jwtMock.signAsync.mockResolvedValue('token');

    await expect(
      service.login({
        email: 'admin@rentamivar.com',
        password: 'Admin123!',
      }),
    ).resolves.toEqual({
      accessToken: 'token',
      user: {
        sub: 'user-1',
        email: 'admin@rentamivar.com',
        fullName: 'Admin',
        role: 'ADMIN',
      },
    });
  });

  it('should reject invalid credentials', async () => {
    prismaMock.user.findUnique.mockResolvedValue(null);

    await expect(
      service.login({
        email: 'admin@rentamivar.com',
        password: 'bad-password',
      }),
    ).rejects.toBeInstanceOf(UnauthorizedException);
  });
});

function hashPassword(password: string) {
  const salt = 'rentamivar-admin-seed';
  const hash = scryptSync(password, salt, 64).toString('hex');

  return `scrypt:${salt}:${hash}`;
}
