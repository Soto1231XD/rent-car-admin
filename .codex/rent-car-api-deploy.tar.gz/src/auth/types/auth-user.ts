import { UserRole } from '@prisma/client';

export type AuthUser = {
  sub: string;
  email: string;
  fullName: string;
  role: UserRole;
};
