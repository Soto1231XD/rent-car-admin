import { Module } from '@nestjs/common';
import { JwtModule, JwtSignOptions } from '@nestjs/jwt';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './jwt-auth.guard';

const jwtExpiresIn = (process.env.JWT_EXPIRES_IN ??
  '8h') as JwtSignOptions['expiresIn'];

const signOptions: JwtSignOptions = {
  expiresIn: jwtExpiresIn,
};

@Module({
  imports: [
    JwtModule.register({
      secret: process.env.JWT_SECRET ?? 'rentamivar-dev-secret',
      signOptions,
    }),
  ],
  controllers: [AuthController],
  providers: [AuthService, JwtAuthGuard],
  exports: [AuthService, JwtAuthGuard, JwtModule],
})
export class AuthModule {}
