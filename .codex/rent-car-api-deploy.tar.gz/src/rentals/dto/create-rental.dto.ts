import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { RentalPriceMode, RentalStatus, RenterType } from '@prisma/client';
import {
  IsDateString,
  IsEnum,
  IsNumber,
  IsOptional,
  IsString,
  Min,
  MinLength,
} from 'class-validator';

export class CreateRentalDto {
  @ApiProperty()
  @IsString()
  @MinLength(1)
  clientId: string;

  @ApiProperty()
  @IsString()
  @MinLength(1)
  carId: string;

  @ApiProperty()
  @IsDateString()
  startDate: string;

  @ApiProperty()
  @IsDateString()
  endDate: string;

  @ApiProperty()
  @IsNumber()
  @Min(0)
  totalPrice: number;

  @ApiPropertyOptional({ enum: RenterType })
  @IsOptional()
  @IsEnum(RenterType)
  renterType?: RenterType;

  @ApiPropertyOptional({ enum: RentalPriceMode })
  @IsOptional()
  @IsEnum(RentalPriceMode)
  priceMode?: RentalPriceMode;

  @ApiPropertyOptional({ enum: RentalStatus })
  @IsOptional()
  @IsEnum(RentalStatus)
  status?: RentalStatus;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;
}
