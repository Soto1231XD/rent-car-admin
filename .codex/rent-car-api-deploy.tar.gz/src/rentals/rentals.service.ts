import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  Car,
  CarStatus,
  RentalPriceMode,
  RentalStatus,
  RenterType,
} from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CreateRentalDto } from './dto/create-rental.dto';
import { UpdateRentalDto } from './dto/update-rental.dto';

const blockingRentalStatuses: RentalStatus[] = [
  RentalStatus.RESERVACION,
  RentalStatus.ACTIVO,
];

@Injectable()
export class RentalsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(createRentalDto: CreateRentalDto) {
    const startDate = new Date(createRentalDto.startDate);
    const endDate = new Date(createRentalDto.endDate);
    const status = createRentalDto.status ?? RentalStatus.RESERVACION;
    const renterType = createRentalDto.renterType ?? RenterType.CLIENTE;

    validateRentalStatusFlow(undefined, status);

    const priceBreakdown = await this.calculatePriceBreakdown({
      carId: createRentalDto.carId,
      startDate,
      endDate,
      renterType,
    });

    await this.validateRentalAvailability({
      carId: createRentalDto.carId,
      startDate,
      endDate,
      status,
    });

    const rental = await this.prisma.rental.create({
      data: {
        ...createRentalDto,
        startDate,
        endDate,
        renterType,
        ...priceBreakdown,
      },
      include: rentalInclude,
    });

    await this.syncCarStatus(rental.carId, rental.status);

    return rental;
  }

  findAll() {
    return this.prisma.rental.findMany({
      include: rentalInclude,
      orderBy: {
        createdAt: 'desc',
      },
    });
  }

  async findOne(id: string) {
    const rental = await this.prisma.rental.findUnique({
      where: { id },
      include: rentalInclude,
    });

    if (!rental) {
      throw new NotFoundException('Renta no encontrada');
    }

    return rental;
  }

  async update(id: string, updateRentalDto: UpdateRentalDto) {
    const currentRental = await this.findOne(id);
    const startDate = updateRentalDto.startDate
      ? new Date(updateRentalDto.startDate)
      : currentRental.startDate;
    const endDate = updateRentalDto.endDate
      ? new Date(updateRentalDto.endDate)
      : currentRental.endDate;
    const carId = updateRentalDto.carId ?? currentRental.carId;
    const status = updateRentalDto.status ?? currentRental.status;
    const renterType = updateRentalDto.renterType ?? currentRental.renterType;

    validateRentalStatusFlow(currentRental.status, status);

    const priceBreakdown = await this.calculatePriceBreakdown({
      carId,
      startDate,
      endDate,
      renterType,
    });

    await this.validateRentalAvailability({
      carId,
      startDate,
      endDate,
      status,
      rentalIdToIgnore: id,
    });

    const rental = await this.prisma.rental.update({
      where: { id },
      data: {
        ...updateRentalDto,
        startDate,
        endDate,
        renterType,
        ...priceBreakdown,
      },
      include: rentalInclude,
    });

    await this.syncCarStatus(rental.carId, rental.status);

    if (currentRental.carId !== rental.carId) {
      await this.refreshCarStatus(currentRental.carId);
    }

    return rental;
  }

  async remove(id: string) {
    const rental = await this.findOne(id);

    const deletedRental = await this.prisma.rental.delete({
      where: { id },
    });

    await this.refreshCarStatus(rental.carId);

    return deletedRental;
  }

  private async validateRentalAvailability({
    carId,
    startDate,
    endDate,
    status,
    rentalIdToIgnore,
  }: {
    carId: string;
    startDate: Date;
    endDate: Date;
    status: RentalStatus;
    rentalIdToIgnore?: string;
  }) {
    if (Number.isNaN(startDate.getTime()) || Number.isNaN(endDate.getTime())) {
      throw new BadRequestException('Las fechas de la renta no son validas');
    }

    if (endDate < startDate) {
      throw new BadRequestException(
        'La fecha de devolucion no puede ser anterior a la fecha de entrega',
      );
    }

    if (!blockingRentalStatuses.includes(status)) {
      return;
    }

    await this.validateCarCanBeRented(carId, status);

    const conflictingRental = await this.prisma.rental.findFirst({
      where: {
        carId,
        id: rentalIdToIgnore ? { not: rentalIdToIgnore } : undefined,
        status: {
          in: blockingRentalStatuses,
        },
        startDate: {
          lte: endDate,
        },
        endDate: {
          gte: startDate,
        },
      },
      select: {
        id: true,
        startDate: true,
        endDate: true,
      },
    });

    if (conflictingRental) {
      throw new BadRequestException(
        `El carro ya tiene una renta activa o reservada del ${formatDate(conflictingRental.startDate)} al ${formatDate(conflictingRental.endDate)}`,
      );
    }
  }

  private async calculatePriceBreakdown({
    carId,
    startDate,
    endDate,
    renterType,
  }: {
    carId: string;
    startDate: Date;
    endDate: Date;
    renterType: RenterType;
  }) {
    const car = await this.prisma.car.findUnique({
      where: { id: carId },
    });

    if (!car) {
      throw new NotFoundException('Carro no encontrado');
    }

    const daysCharged = getRentalDays(startDate, endDate);
    const shouldUseHighSeasonRate =
      Boolean(car.highSeasonPrice) &&
      hasHighSeasonDate(startDate, daysCharged);
    const priceMode = shouldUseHighSeasonRate
      ? RentalPriceMode.TEMPORADA_ALTA
      : RentalPriceMode.NORMAL;
    const dailyRateApplied = getDailyRate(car, priceMode, renterType);

    return {
      renterType,
      priceMode,
      dailyRateApplied,
      daysCharged,
      totalPrice: dailyRateApplied * daysCharged,
    };
  }

  private async syncCarStatus(carId: string, rentalStatus: RentalStatus) {
    if (rentalStatus === RentalStatus.ACTIVO) {
      return this.prisma.car.update({
        where: { id: carId },
        data: {
          status: CarStatus.RENTADO,
        },
      });
    }

    return this.refreshCarStatus(carId);
  }

  private async refreshCarStatus(carId: string) {
    const activeRental = await this.prisma.rental.findFirst({
      where: {
        carId,
        status: RentalStatus.ACTIVO,
      },
      select: {
        id: true,
      },
    });

    return this.prisma.car.update({
      where: { id: carId },
      data: {
        status: activeRental ? CarStatus.RENTADO : CarStatus.DISPONIBLE,
      },
    });
  }

  private async validateCarCanBeRented(carId: string, rentalStatus: RentalStatus) {
    if (!blockingRentalStatuses.includes(rentalStatus)) {
      return;
    }

    const car = await this.prisma.car.findUnique({
      where: { id: carId },
      select: {
        status: true,
      },
    });

    if (!car) {
      throw new NotFoundException('Carro no encontrado');
    }

    if (car.status === CarStatus.MANTENIMIENTO) {
      throw new BadRequestException(
        'Este carro está en mantenimiento y no se puede rentar.',
      );
    }

    if (car.status === CarStatus.NO_DISPONIBLE) {
      throw new BadRequestException(
        'Este carro está marcado como no disponible y no se puede rentar.',
      );
    }
  }
}

const rentalInclude = {
  client: true,
  car: true,
};

function formatDate(value: Date) {
  return value.toISOString().slice(0, 10);
}

function getRentalDays(startDate: Date, endDate: Date) {
  if (Number.isNaN(startDate.getTime()) || Number.isNaN(endDate.getTime())) {
    return 1;
  }

  const millisecondsPerDay = 1000 * 60 * 60 * 24;
  const difference = Math.round(
    (endDate.getTime() - startDate.getTime()) / millisecondsPerDay,
  );

  return Math.max(1, difference);
}

function getDailyRate(
  car: Car,
  priceMode: RentalPriceMode,
  renterType: RenterType,
) {
  if (renterType === RenterType.COMISIONISTA) {
    if (
      priceMode === RentalPriceMode.TEMPORADA_ALTA &&
      car.commissionHighSeasonPrice
    ) {
      return Number(car.commissionHighSeasonPrice);
    }

    if (car.commissionDailyPrice) {
      return Number(car.commissionDailyPrice);
    }
  }

  if (priceMode === RentalPriceMode.TEMPORADA_ALTA && car.highSeasonPrice) {
    return Number(car.highSeasonPrice);
  }

  return Number(car.dailyPrice);
}

function hasHighSeasonDate(startDate: Date, daysCharged: number) {
  return Array.from({ length: daysCharged }).some((_, index) => {
    const currentDate = new Date(startDate);
    currentDate.setUTCDate(startDate.getUTCDate() + index);

    return isHighSeasonDate(currentDate);
  });
}

function isHighSeasonDate(date: Date) {
  const month = date.getUTCMonth() + 1;
  const day = date.getUTCDate();
  const monthDay = month * 100 + day;

  return (
    (monthDay >= 701 && monthDay <= 831) ||
    monthDay >= 1201 ||
    monthDay <= 115 ||
    (monthDay >= 320 && monthDay <= 415)
  );
}

function validateRentalStatusFlow(
  currentStatus: RentalStatus | undefined,
  nextStatus: RentalStatus,
) {
  if (!currentStatus && nextStatus === RentalStatus.COMPLETADO) {
    throw new BadRequestException(
      'No se puede crear una renta directamente como completada.',
    );
  }

  if (
    currentStatus === RentalStatus.CANCELADO &&
    nextStatus !== RentalStatus.CANCELADO
  ) {
    throw new BadRequestException(
      'No se puede reactivar una renta cancelada. Crea una nueva renta.',
    );
  }

  if (
    nextStatus === RentalStatus.COMPLETADO &&
    currentStatus !== RentalStatus.RESERVACION &&
    currentStatus !== RentalStatus.ACTIVO &&
    currentStatus !== RentalStatus.COMPLETADO
  ) {
    throw new BadRequestException(
      'Solo se puede completar una renta activa o reservada.',
    );
  }
}
