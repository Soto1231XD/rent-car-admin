import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ExtraExpenseStatus } from '@prisma/client';
import {
  IsDateString,
  IsEnum,
  IsNumber,
  IsOptional,
  IsString,
  Min,
  MinLength,
} from 'class-validator';

export class CreateExtraExpenseDto {
  @ApiProperty()
  @IsString()
  @MinLength(1)
  carId: string;

  @ApiProperty()
  @IsString()
  @MinLength(1)
  concept: string;

  @ApiProperty()
  @IsNumber()
  @Min(0)
  cost: number;

  @ApiProperty()
  @IsDateString()
  date: string;

  @ApiPropertyOptional({ enum: ExtraExpenseStatus })
  @IsOptional()
  @IsEnum(ExtraExpenseStatus)
  status?: ExtraExpenseStatus;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;
}
