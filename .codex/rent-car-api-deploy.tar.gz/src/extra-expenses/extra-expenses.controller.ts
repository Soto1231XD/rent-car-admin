import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CreateExtraExpenseDto } from './dto/create-extra-expense.dto';
import { UpdateExtraExpenseDto } from './dto/update-extra-expense.dto';
import { ExtraExpensesService } from './extra-expenses.service';

@ApiTags('Extra expenses')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
@Controller('extra-expenses')
export class ExtraExpensesController {
  constructor(private readonly extraExpensesService: ExtraExpensesService) {}

  @Post()
  create(@Body() createExtraExpenseDto: CreateExtraExpenseDto) {
    return this.extraExpensesService.create(createExtraExpenseDto);
  }

  @Get()
  findAll() {
    return this.extraExpensesService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.extraExpensesService.findOne(id);
  }

  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() updateExtraExpenseDto: UpdateExtraExpenseDto,
  ) {
    return this.extraExpensesService.update(id, updateExtraExpenseDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.extraExpensesService.remove(id);
  }
}
