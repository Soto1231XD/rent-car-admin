import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { PrismaModule } from '../prisma/prisma.module';
import { ExtraExpensesController } from './extra-expenses.controller';
import { ExtraExpensesService } from './extra-expenses.service';

@Module({
  imports: [PrismaModule, AuthModule],
  controllers: [ExtraExpensesController],
  providers: [ExtraExpensesService],
})
export class ExtraExpensesModule {}
