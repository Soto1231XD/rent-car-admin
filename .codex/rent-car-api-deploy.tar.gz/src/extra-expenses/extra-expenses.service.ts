import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { ExtraExpenseStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CreateExtraExpenseDto } from './dto/create-extra-expense.dto';
import { UpdateExtraExpenseDto } from './dto/update-extra-expense.dto';

@Injectable()
export class ExtraExpensesService {
  constructor(private readonly prisma: PrismaService) {}

  async create(createExtraExpenseDto: CreateExtraExpenseDto) {
    const date = parseExtraExpenseDate(createExtraExpenseDto.date);
    validateExtraExpenseDate(date, createExtraExpenseDto.status);

    return this.prisma.extraExpense.create({
      data: {
        ...createExtraExpenseDto,
        date,
      },
      include: extraExpenseInclude,
    });
  }

  findAll() {
    return this.prisma.extraExpense.findMany({
      include: extraExpenseInclude,
      orderBy: {
        date: 'desc',
      },
    });
  }

  async findOne(id: string) {
    const extraExpense = await this.prisma.extraExpense.findUnique({
      where: { id },
      include: extraExpenseInclude,
    });

    if (!extraExpense) {
      throw new NotFoundException('Gasto extra no encontrado');
    }

    return extraExpense;
  }

  async update(id: string, updateExtraExpenseDto: UpdateExtraExpenseDto) {
    const currentExtraExpense = await this.findOne(id);
    const date = updateExtraExpenseDto.date
      ? parseExtraExpenseDate(updateExtraExpenseDto.date)
      : currentExtraExpense.date;
    const status = updateExtraExpenseDto.status ?? currentExtraExpense.status;

    validateExtraExpenseDate(date, status);

    return this.prisma.extraExpense.update({
      where: { id },
      data: {
        ...updateExtraExpenseDto,
        date,
      },
      include: extraExpenseInclude,
    });
  }

  async remove(id: string) {
    await this.findOne(id);

    return this.prisma.extraExpense.delete({
      where: { id },
    });
  }
}

const extraExpenseInclude = {
  car: true,
};

function parseExtraExpenseDate(value: string) {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    throw new BadRequestException('La fecha del gasto extra no es valida.');
  }

  return date;
}

function validateExtraExpenseDate(date: Date, status?: ExtraExpenseStatus) {
  const minDate = new Date('2000-01-01T00:00:00.000Z');

  if (date < minDate) {
    throw new BadRequestException(
      'La fecha del gasto extra no puede ser anterior al ano 2000.',
    );
  }

  if (status === ExtraExpenseStatus.PAGADO && date > new Date()) {
    throw new BadRequestException(
      'No se puede marcar como pagado un gasto extra con fecha futura.',
    );
  }
}
