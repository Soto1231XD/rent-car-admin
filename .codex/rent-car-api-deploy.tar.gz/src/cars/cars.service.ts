import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CarStatus, Prisma, RentalStatus, Transmission } from '@prisma/client';
import { randomUUID } from 'crypto';
import { mkdir, writeFile } from 'fs/promises';
import { extname, join } from 'path';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCarDto } from './dto/create-car.dto';
import { UpdateCarDto } from './dto/update-car.dto';

const MAX_IMAGE_SIZE = 5 * 1024 * 1024;
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const PUBLIC_CAR_STATUSES = [CarStatus.DISPONIBLE, CarStatus.RENTADO];

@Injectable()
export class CarsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(createCarDto: CreateCarDto) {
    try {
      const data = normalizeCarPayload(createCarDto) as Prisma.CarCreateInput;

      return await this.prisma.car.create({
        data: {
          ...data,
          features: createCarDto.features ?? [],
          images: createCarDto.images ?? [],
        },
      });
    } catch (error) {
      handleCarPersistenceError(error);
    }
  }

  findAll() {
    return this.prisma.car.findMany({
      orderBy: {
        createdAt: 'desc',
      },
    });
  }

  async findPublic() {
    const cars = await this.prisma.car.findMany({
      where: {
        status: {
          in: PUBLIC_CAR_STATUSES,
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    return cars.map((car) => ({
      id: car.id,
      name: `${car.brand} ${car.model} ${car.year}`,
      brand: car.brand,
      model: car.model,
      year: car.year,
      passengers: car.passengers,
      transmission: formatTransmission(car.transmission),
      engineType: car.engineType,
      displacement: car.displacement,
      hasCarPlay: car.hasCarPlay,
      trunkCapacity: car.trunkCapacity,
      dailyPrice: Number(car.dailyPrice),
      highSeasonPrice: car.highSeasonPrice
        ? Number(car.highSeasonPrice)
        : null,
      commissionDailyPrice: car.commissionDailyPrice
        ? Number(car.commissionDailyPrice)
        : null,
      commissionHighSeasonPrice: car.commissionHighSeasonPrice
        ? Number(car.commissionHighSeasonPrice)
        : null,
      status: formatCarStatus(car.status),
      image: car.images[0] ?? null,
      images: car.images,
      features: car.features,
      description: car.description,
    }));
  }

  async findPublicOne(id: string) {
    const car = await this.prisma.car.findFirst({
      where: {
        id,
        status: {
          in: PUBLIC_CAR_STATUSES,
        },
      },
    });

    if (!car) {
      throw new NotFoundException('Carro no encontrado');
    }

    return {
      id: car.id,
      name: `${car.brand} ${car.model} ${car.year}`,
      brand: car.brand,
      model: car.model,
      year: car.year,
      passengers: car.passengers,
      transmission: formatTransmission(car.transmission),
      engineType: car.engineType,
      displacement: car.displacement,
      hasCarPlay: car.hasCarPlay,
      trunkCapacity: car.trunkCapacity,
      dailyPrice: Number(car.dailyPrice),
      highSeasonPrice: car.highSeasonPrice
        ? Number(car.highSeasonPrice)
        : null,
      commissionDailyPrice: car.commissionDailyPrice
        ? Number(car.commissionDailyPrice)
        : null,
      commissionHighSeasonPrice: car.commissionHighSeasonPrice
        ? Number(car.commissionHighSeasonPrice)
        : null,
      status: formatCarStatus(car.status),
      image: car.images[0] ?? null,
      images: car.images,
      features: car.features,
      description: car.description,
    };
  }

  async findPublicAvailability(id: string) {
    const car = await this.prisma.car.findUnique({
      where: { id },
      select: { id: true },
    });

    if (!car) {
      throw new NotFoundException('Carro no encontrado');
    }

    return this.prisma.rental.findMany({
      where: {
        carId: id,
        status: {
          in: [RentalStatus.RESERVACION, RentalStatus.ACTIVO],
        },
      },
      select: {
        startDate: true,
        endDate: true,
      },
      orderBy: {
        startDate: 'asc',
      },
    });
  }

  async findOne(id: string) {
    const car = await this.prisma.car.findUnique({
      where: { id },
    });

    if (!car) {
      throw new NotFoundException('Carro no encontrado');
    }

    return car;
  }

  async update(id: string, updateCarDto: UpdateCarDto) {
    await this.findOne(id);

    try {
      return await this.prisma.car.update({
        where: { id },
        data: normalizeCarPayload(updateCarDto) as Prisma.CarUpdateInput,
      });
    } catch (error) {
      handleCarPersistenceError(error);
    }
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.validateCarCanBeDeleted(id);

    try {
      return await this.prisma.car.delete({
        where: { id },
      });
    } catch (error) {
      handleCarPersistenceError(error);
    }
  }

  async addImages(id: string, files: UploadedCarImage[]) {
    const car = await this.findOne(id);

    if (!files.length) {
      throw new BadRequestException('Agrega al menos una imagen');
    }

    const uploadDir = join(process.cwd(), 'public', 'uploads', 'cars', id);
    await mkdir(uploadDir, { recursive: true });

    const imagePaths = await Promise.all(
      files.map(async (file) => {
        validateImage(file);

        const extension = getImageExtension(file);
        const filename = `${Date.now()}-${randomUUID()}${extension}`;
        const filePath = join(uploadDir, filename);

        await writeFile(filePath, file.buffer);

        return `/uploads/cars/${id}/${filename}`;
      }),
    );

    return this.prisma.car.update({
      where: { id },
      data: {
        images: [...car.images, ...imagePaths],
      },
    });
  }

  private async validateCarCanBeDeleted(id: string) {
    const activeRental = await this.prisma.rental.findFirst({
      where: {
        carId: id,
        status: {
          in: [RentalStatus.RESERVACION, RentalStatus.ACTIVO],
        },
      },
      select: {
        id: true,
      },
    });

    if (activeRental) {
      throw new BadRequestException(
        'No se puede eliminar este carro porque tiene una renta activa o reservada.',
      );
    }

    const [rentalsCount, maintenancesCount, extraExpensesCount] =
      await Promise.all([
      this.prisma.rental.count({
        where: { carId: id },
      }),
      this.prisma.maintenance.count({
        where: { carId: id },
      }),
      this.prisma.extraExpense.count({
        where: { carId: id },
      }),
    ]);

    if (rentalsCount > 0 || maintenancesCount > 0 || extraExpensesCount > 0) {
      throw new BadRequestException(
        'No se puede eliminar este carro porque ya tiene historial. Cámbialo a No disponible si ya no se va a rentar.',
      );
    }
  }
}

function normalizeCarPayload(carDto: CreateCarDto | UpdateCarDto) {
  return {
    ...carDto,
    plate: normalizeOptionalText(carDto.plate),
    color: normalizeOptionalText(carDto.color),
    engineType: normalizeOptionalText(carDto.engineType),
    displacement: normalizeOptionalText(carDto.displacement),
    trunkCapacity: normalizeOptionalText(carDto.trunkCapacity),
    description: normalizeOptionalText(carDto.description),
  };
}

function normalizeOptionalText(value?: string | null) {
  if (typeof value !== 'string') {
    return value;
  }

  const trimmedValue = value.trim();

  return trimmedValue || null;
}

function formatCarStatus(status: CarStatus) {
  switch (status) {
    case CarStatus.DISPONIBLE:
      return 'Disponible';
    case CarStatus.RENTADO:
      return 'Rentado';
    case CarStatus.MANTENIMIENTO:
      return 'Mantenimiento';
    case CarStatus.NO_DISPONIBLE:
      return 'No disponible';
    default:
      return status;
  }
}

type UploadedCarImage = {
  originalname?: string;
  mimetype?: string;
  size?: number;
  buffer: Buffer;
};

function validateImage(file: UploadedCarImage) {
  if (!file.buffer) {
    throw new BadRequestException('No se pudo leer la imagen');
  }

  if (!file.mimetype || !ALLOWED_IMAGE_TYPES.includes(file.mimetype)) {
    throw new BadRequestException('Solo se permiten imagenes JPG, PNG o WEBP');
  }

  if (file.size && file.size > MAX_IMAGE_SIZE) {
    throw new BadRequestException('Cada imagen debe pesar maximo 5 MB');
  }
}

function getImageExtension(file: UploadedCarImage) {
  const originalExtension = extname(file.originalname ?? '').toLowerCase();

  if (['.jpg', '.jpeg', '.png', '.webp'].includes(originalExtension)) {
    return originalExtension;
  }

  const extensions: Record<string, string> = {
    'image/jpeg': '.jpg',
    'image/png': '.png',
    'image/webp': '.webp',
  };

  return extensions[file.mimetype ?? ''] ?? '.jpg';
}

function handleCarPersistenceError(error: unknown): never {
  if (
    error instanceof Prisma.PrismaClientKnownRequestError &&
    error.code === 'P2002'
  ) {
    throw new BadRequestException('Ya existe un carro con esa placa.');
  }

  if (
    error instanceof Prisma.PrismaClientKnownRequestError &&
    error.code === 'P2003'
  ) {
    throw new BadRequestException(
      'No se puede eliminar este carro porque tiene registros relacionados.',
    );
  }

  throw error;
}

function formatTransmission(transmission: Transmission) {
  switch (transmission) {
    case Transmission.AUTOMATICO:
      return 'Automático';
    case Transmission.ESTANDAR:
      return 'Estándar';
    default:
      return transmission;
  }
}
