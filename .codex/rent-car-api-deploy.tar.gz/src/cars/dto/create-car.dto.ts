import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { CarStatus, Transmission } from '@prisma/client';
import {
  IsArray,
  IsBoolean,
  IsEnum,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  Max,
  Min,
  MinLength,
} from 'class-validator';

export class CreateCarDto {
  @ApiProperty()
  @IsString()
  @MinLength(1)
  brand: string;

  @ApiProperty()
  @IsString()
  @MinLength(1)
  model: string;

  @ApiProperty()
  @IsInt()
  @Min(1990)
  @Max(new Date().getFullYear() + 1)
  year: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  plate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  color?: string;

  @ApiProperty()
  @IsInt()
  @Min(1)
  passengers: number;

  @ApiProperty({ enum: Transmission })
  @IsEnum(Transmission)
  transmission: Transmission;

  @ApiPropertyOptional({ example: 'Gasolina' })
  @IsOptional()
  @IsString()
  engineType?: string;

  @ApiPropertyOptional({ example: '1.6 L' })
  @IsOptional()
  @IsString()
  displacement?: string;

  @ApiPropertyOptional({ example: true })
  @IsOptional()
  @IsBoolean()
  hasCarPlay?: boolean;

  @ApiPropertyOptional({ example: '2 maletas grandes' })
  @IsOptional()
  @IsString()
  trunkCapacity?: string;

  @ApiProperty()
  @IsNumber()
  @Min(0)
  dailyPrice: number;

  @ApiProperty()
  @IsNumber()
  @Min(0)
  highSeasonPrice: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @Min(0)
  commissionDailyPrice?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @Min(0)
  commissionHighSeasonPrice?: number;

  @ApiProperty()
  @IsNumber()
  @Min(0)
  deposit: number;

  @ApiProperty({ enum: CarStatus })
  @IsEnum(CarStatus)
  status: CarStatus;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ type: [String] })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  features?: string[];

  @ApiPropertyOptional({ type: [String] })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  images?: string[];
}
