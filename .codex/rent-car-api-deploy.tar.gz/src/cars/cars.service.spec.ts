import { NotFoundException } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { PrismaService } from '../prisma/prisma.service';
import { CarsService } from './cars.service';

describe('CarsService', () => {
  let service: CarsService;

  const prismaMock = {
    car: {
      create: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CarsService,
        {
          provide: PrismaService,
          useValue: prismaMock,
        },
      ],
    }).compile();

    service = module.get<CarsService>(CarsService);
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should return all cars ordered by newest first', async () => {
    const cars = [{ id: 'car-1', brand: 'Nissan' }];
    prismaMock.car.findMany.mockResolvedValue(cars);

    await expect(service.findAll()).resolves.toBe(cars);
    expect(prismaMock.car.findMany).toHaveBeenCalledWith({
      orderBy: {
        createdAt: 'desc',
      },
    });
  });

  it('should throw NotFoundException when a car does not exist', async () => {
    prismaMock.car.findUnique.mockResolvedValue(null);

    await expect(service.findOne('missing-id')).rejects.toBeInstanceOf(
      NotFoundException,
    );
  });
});
