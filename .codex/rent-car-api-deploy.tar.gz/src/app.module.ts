import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { CarsModule } from './cars/cars.module';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { ClientsModule } from './clients/clients.module';
import { RentalsModule } from './rentals/rentals.module';
import { MaintenancesModule } from './maintenances/maintenances.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { ExtraExpensesModule } from './extra-expenses/extra-expenses.module';

@Module({
  imports: [
    CarsModule,
    PrismaModule,
    AuthModule,
    ClientsModule,
    RentalsModule,
    MaintenancesModule,
    ExtraExpensesModule,
    DashboardModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
