import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CreateClientDto } from './dto/create-client.dto';
import { UpdateClientDto } from './dto/update-client.dto';

@Injectable()
export class ClientsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(createClientDto: CreateClientDto) {
    try {
      return await this.prisma.client.create({
        data: createClientDto,
      });
    } catch (error) {
      handleClientPersistenceError(error);
    }
  }

  findAll() {
    return this.prisma.client.findMany({
      orderBy: {
        createdAt: 'desc',
      },
    });
  }

  async findOne(id: string) {
    const client = await this.prisma.client.findUnique({
      where: { id },
      include: {
        rentals: {
          include: {
            car: true,
          },
          orderBy: {
            startDate: 'desc',
          },
        },
      },
    });

    if (!client) {
      throw new NotFoundException('Cliente no encontrado');
    }

    return client;
  }

  async update(id: string, updateClientDto: UpdateClientDto) {
    await this.findOne(id);

    try {
      return await this.prisma.client.update({
        where: { id },
        data: updateClientDto,
      });
    } catch (error) {
      handleClientPersistenceError(error);
    }
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.validateClientCanBeDeleted(id);

    try {
      return await this.prisma.client.delete({
        where: { id },
      });
    } catch (error) {
      handleClientPersistenceError(error);
    }
  }

  private async validateClientCanBeDeleted(id: string) {
    const rentalsCount = await this.prisma.rental.count({
      where: { clientId: id },
    });

    if (rentalsCount > 0) {
      throw new BadRequestException(
        'No se puede eliminar este cliente porque tiene rentas registradas.',
      );
    }
  }
}

function handleClientPersistenceError(error: unknown): never {
  if (
    error instanceof Prisma.PrismaClientKnownRequestError &&
    error.code === 'P2002'
  ) {
    throw new BadRequestException('Ya existe un cliente con ese correo.');
  }

  if (
    error instanceof Prisma.PrismaClientKnownRequestError &&
    error.code === 'P2003'
  ) {
    throw new BadRequestException(
      'No se puede eliminar este cliente porque tiene registros relacionados.',
    );
  }

  throw error;
}
