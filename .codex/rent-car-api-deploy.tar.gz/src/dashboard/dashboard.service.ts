import { Injectable } from '@nestjs/common';
import {
  CarStatus,
  MaintenanceStatus,
  RentalStatus,
  RenterType,
} from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class DashboardService {
  constructor(private readonly prisma: PrismaService) {}

  async getSummary() {
    const currentMonthStart = new Date();
    currentMonthStart.setDate(1);
    currentMonthStart.setHours(0, 0, 0, 0);

    const [
      totalCars,
      availableCars,
      rentedCars,
      maintenanceCars,
      unavailableCars,
      totalClients,
      activeRentals,
      reservedRentals,
      completedRentals,
      pendingMaintenances,
      inProgressMaintenances,
      monthlyIncome,
      monthlyCommissionerIncome,
      upcomingRentals,
      pendingMaintenanceList,
    ] = await Promise.all([
      this.prisma.car.count(),
      this.prisma.car.count({ where: { status: CarStatus.DISPONIBLE } }),
      this.prisma.car.count({ where: { status: CarStatus.RENTADO } }),
      this.prisma.car.count({ where: { status: CarStatus.MANTENIMIENTO } }),
      this.prisma.car.count({ where: { status: CarStatus.NO_DISPONIBLE } }),
      this.prisma.client.count(),
      this.prisma.rental.count({ where: { status: RentalStatus.ACTIVO } }),
      this.prisma.rental.count({
        where: { status: RentalStatus.RESERVACION },
      }),
      this.prisma.rental.count({
        where: { status: RentalStatus.COMPLETADO },
      }),
      this.prisma.maintenance.count({
        where: { status: MaintenanceStatus.PENDIENTE },
      }),
      this.prisma.maintenance.count({
        where: { status: MaintenanceStatus.EN_PROGRESO },
      }),
      this.prisma.rental.aggregate({
        where: {
          status: RentalStatus.COMPLETADO,
          endDate: {
            gte: currentMonthStart,
          },
        },
        _sum: {
          totalPrice: true,
        },
      }),
      this.prisma.rental.aggregate({
        where: {
          status: RentalStatus.COMPLETADO,
          renterType: RenterType.COMISIONISTA,
          endDate: {
            gte: currentMonthStart,
          },
        },
        _sum: {
          totalPrice: true,
        },
      }),
      this.prisma.rental.findMany({
        where: {
          status: {
            in: [RentalStatus.RESERVACION, RentalStatus.ACTIVO],
          },
        },
        include: {
          client: true,
          car: true,
        },
        orderBy: {
          startDate: 'asc',
        },
        take: 5,
      }),
      this.prisma.maintenance.findMany({
        where: {
          status: {
            in: [MaintenanceStatus.PENDIENTE, MaintenanceStatus.EN_PROGRESO],
          },
        },
        include: {
          car: true,
        },
        orderBy: {
          date: 'asc',
        },
        take: 5,
      }),
    ]);

    return {
      cars: {
        total: totalCars,
        available: availableCars,
        rented: rentedCars,
        maintenance: maintenanceCars,
        unavailable: unavailableCars,
      },
      clients: {
        total: totalClients,
      },
      rentals: {
        active: activeRentals,
        reserved: reservedRentals,
        completed: completedRentals,
      },
      maintenances: {
        pending: pendingMaintenances,
        inProgress: inProgressMaintenances,
      },
      income: {
        currentMonth: Number(monthlyIncome._sum.totalPrice ?? 0),
        commissionerCurrentMonth: Number(
          monthlyCommissionerIncome._sum.totalPrice ?? 0,
        ),
      },
      upcomingRentals,
      pendingMaintenanceList,
    };
  }
}
