import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CarStatus, MaintenanceStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CreateMaintenanceDto } from './dto/create-maintenance.dto';
import { UpdateMaintenanceDto } from './dto/update-maintenance.dto';

@Injectable()
export class MaintenancesService {
  constructor(private readonly prisma: PrismaService) {}

  async create(createMaintenanceDto: CreateMaintenanceDto) {
    const date = parseMaintenanceDate(createMaintenanceDto.date);
    validateMaintenanceDate(date, createMaintenanceDto.status);

    const maintenance = await this.prisma.maintenance.create({
      data: {
        ...createMaintenanceDto,
        date,
      },
      include: maintenanceInclude,
    });

    await this.syncCarStatus(maintenance.carId, maintenance.status);

    return maintenance;
  }

  findAll() {
    return this.prisma.maintenance.findMany({
      include: maintenanceInclude,
      orderBy: {
        date: 'desc',
      },
    });
  }

  async findOne(id: string) {
    const maintenance = await this.prisma.maintenance.findUnique({
      where: { id },
      include: maintenanceInclude,
    });

    if (!maintenance) {
      throw new NotFoundException('Mantenimiento no encontrado');
    }

    return maintenance;
  }

  async update(id: string, updateMaintenanceDto: UpdateMaintenanceDto) {
    const currentMaintenance = await this.findOne(id);
    const date = updateMaintenanceDto.date
      ? parseMaintenanceDate(updateMaintenanceDto.date)
      : currentMaintenance.date;
    const status = updateMaintenanceDto.status ?? currentMaintenance.status;

    validateMaintenanceDate(date, status);

    const maintenance = await this.prisma.maintenance.update({
      where: { id },
      data: {
        ...updateMaintenanceDto,
        date,
      },
      include: maintenanceInclude,
    });

    await this.syncCarStatus(maintenance.carId, maintenance.status);

    return maintenance;
  }

  async remove(id: string) {
    const maintenance = await this.findOne(id);
    await this.syncCarStatus(maintenance.carId, MaintenanceStatus.COMPLETADO);

    return this.prisma.maintenance.delete({
      where: { id },
    });
  }

  private syncCarStatus(carId: string, maintenanceStatus: MaintenanceStatus) {
    const nextStatus =
      maintenanceStatus === MaintenanceStatus.COMPLETADO
        ? CarStatus.DISPONIBLE
        : CarStatus.MANTENIMIENTO;

    return this.prisma.car.update({
      where: { id: carId },
      data: {
        status: nextStatus,
      },
    });
  }
}

const maintenanceInclude = {
  car: true,
};

function parseMaintenanceDate(value: string) {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    throw new BadRequestException('La fecha del mantenimiento no es válida.');
  }

  return date;
}

function validateMaintenanceDate(date: Date, status?: MaintenanceStatus) {
  const minDate = new Date('2000-01-01T00:00:00.000Z');

  if (date < minDate) {
    throw new BadRequestException(
      'La fecha del mantenimiento no puede ser anterior al año 2000.',
    );
  }

  if (status === MaintenanceStatus.COMPLETADO && date > new Date()) {
    throw new BadRequestException(
      'No se puede marcar como completado un mantenimiento con fecha futura.',
    );
  }
}
